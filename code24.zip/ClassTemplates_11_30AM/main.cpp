#include <iostream>

using namespace std;

/*
    Class Templates

    template <class T>

    class classname
    {
        public:

        T a, b, c;

        T function_name()
        {

        }
    };

    classname<int> classobject;
    classname<float> classobject2;

*/
template <class T>
class calculator
{
private:
    T a, b;

public:

    void setData(T x, T y)
    {
        a = x;
        b = y;
    }

    void getData()
    {
        cout<<"Addition is:"<<a+b<<endl;
        cout<<"Subtraction is:"<<a-b<<endl;
        cout<<"Multiplication is:"<<a*b<<endl;
        cout<<"Division is:"<<a/b<<endl;
    }
};

int main()
{
    calculator<int> obj1;
    obj1.setData(20, 10);

    cout<<endl;

    calculator<float> obj2;
    obj2.setData(80.45f, 56.7f);

    cout<<endl;

    calculator<double> obj3;
    obj3.setData(60.80, 40.56);

    cout<<endl;

    cout<<"Integer:"<<endl;
    obj1.getData();

    cout<<endl;

    cout<<"Float:"<<endl;
    obj2.getData();

    cout<<endl;

    cout<<"Double:"<<endl;
    obj3.getData();

    return 0;
}

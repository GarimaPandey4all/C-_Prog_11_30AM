#include <iostream>

using namespace std;

class EvenOdd
{
public:
    int number;

    void isEven()
    {
        cout<<"Enter any number:";
        cin>>number;

        ((number%2) == 0)?cout<<"Number is Even.\n" : cout<<"Number is Odd.\n";
    }
};

int main()
{
    EvenOdd obj1;
    EvenOdd obj2;
    EvenOdd obj3;
    EvenOdd obj4;

    obj1.isEven();
    obj2.isEven();
    obj3.isEven();
    obj4.isEven();

    return 0;
}

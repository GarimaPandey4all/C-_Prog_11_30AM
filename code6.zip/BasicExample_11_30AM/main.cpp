#include <iostream>

using namespace std;

namespace n1
{
    int value = 700;

    void showData()
    {
        cout<<"Hello World.";
    }
}

//:: --> Scope Resolution Operator

//Global Variables
//int value = 700;

int main()
{
    int value = 200;

    cout<<"Value is:"<<value<<endl;

    cout<<"Value is:"<<n1::value<<endl;

    n1::showData();

    return 0;
}

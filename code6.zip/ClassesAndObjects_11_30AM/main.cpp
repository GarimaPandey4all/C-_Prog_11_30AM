#include <iostream>

using namespace std;

class Employee
{
public:

    int id;
    string name;

    void showData()
    {
        cout<<"Employee's Id:"<<id<<endl;
        cout<<"Employee's Name:"<<name<<endl;
    }
};

int main()
{
    Employee E1;

    E1.id = 100;
    E1.name = "Swati";

    E1.showData();

    return 0;
}

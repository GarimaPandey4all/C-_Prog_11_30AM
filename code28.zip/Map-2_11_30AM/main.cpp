#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer;

    customer[100] = "Swati";
    customer[145] = "Rahul";
    customer[235] = "Madhav";
    customer[101] = "Aakash";

    //Or second way is:

    map <int, string> c2 {{100, "Swati"}, {145, "Rahul"}, {235, "Madhav"}, {101, "Aakash"}};

    //Accessing values from the map: First way

    cout<<"Customer 1:"<<customer[100]<<endl;
    cout<<"Customer 2:"<<customer[145]<<endl;
    cout<<"Customer 3:"<<customer[235]<<endl;
    cout<<"Customer 4:"<<customer[101]<<endl<<endl;

    //at()

    cout<<"Customer 3:"<<customer.at(235)<<endl<<endl;

    //Accessing values from the map: second way

    map <int, string> :: iterator ptr = c2.begin();

    while(ptr != c2.end())
    {
        cout<<ptr->first<<endl;
        //cout<<ptr->second<<endl<<endl;
        ++ptr;
    }

    cout<<"Total number of elements:"<<c2.size()<<endl;

    cout<<"Empty is:"<<c2.empty();

    return 0;
}

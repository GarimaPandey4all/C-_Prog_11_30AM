#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer;

    customer[100] = "Swati";
    customer[145] = "Rahul";
    customer[235] = "Madhav";
    customer[101] = "Aakash";

    //Or second way is:

    map <int, string> c2 {{100, "Swati"}, {145, "Rahul"}, {235, "Madhav"}, {101, "Aakash"}};

    return 0;
}

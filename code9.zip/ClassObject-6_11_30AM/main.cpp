#include <iostream>

using namespace std;

class example
{
    int a, b; //private

public:
    void setData(int x, int y) //setter
    {
        a = x;
        b = y;
    }

    void getData() //getter
    {
        cout<<"A is:"<<a<<endl;
        cout<<"B is:"<<b<<endl;
    }
};

int main()
{
    example obj;
    obj.setData(10, 20);
    obj.getData();

    return 0;
}

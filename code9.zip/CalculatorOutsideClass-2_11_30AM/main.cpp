#include <iostream>

using namespace std;

//Function definition outside the class

class Calculator
{
public:
    int a, b;

    void add();
    void sub();
    void mul();
    void div();
};

void Calculator::add()
    {
        cout<<"Addition\n";
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Addition is:"<<a+b<<endl;
    }

void Calculator::sub()
    {
        cout<<"Subtraction\n";
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Subtraction is:"<<a-b<<endl;
    }

void Calculator::mul()
    {
        cout<<"Multiplication\n";
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Multiplication is:"<<a*b<<endl;
    }

void Calculator::div()
    {
        cout<<"Division\n";
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Division is:"<<a/b<<endl;
    }

int main()
{
    Calculator obj;

    obj.add();
    obj.sub();
    obj.mul();
    obj.div();

    return 0;
}

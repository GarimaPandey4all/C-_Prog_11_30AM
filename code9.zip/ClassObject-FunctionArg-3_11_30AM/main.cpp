#include <iostream>

using namespace std;

class Car
{
    public:
    string Brand;
    string Model;
    string Year;

    void Mycar(string x, string y, string z);
//    {
//        Brand = x;
//        Model = y;
//        Year = z;
//    }
};

void Car::Mycar(string x, string y, string z)
{
    Brand = x;
    Model = y;
    Year = z;
}

int main()
{
    Car obj;
    Car obj1;

    obj.Mycar("Maruti Suzuki", "C5", "2019");
    obj1.Mycar("Honda", "H3", "2019");

    cout<<"Brand is:"<<obj.Brand<<endl;
    cout<<"Model is:"<<obj.Model<<endl;
    cout<<"Year is:"<<obj.Year<<endl;

    cout<<"Brand is:"<<obj1.Brand<<endl;
    cout<<"Model is:"<<obj1.Model<<endl;
    cout<<"Year is:"<<obj1.Year<<endl;

    return 0;
}

#include <iostream>

using namespace std;

class Car
{
public:
    string Brand;
    string Model;
    string Year;

    Car(string x, string y, string z);
//    {
//        Brand = x;
//        Model = y;
//        Year = z;
//    }
};

Car::Car(string x, string y, string z)
{
        Brand = x;
        Model = y;
        Year = z;
}

int main()
{
    Car obj("Maruti Suzuki", "C5", "2019");
    Car obj1("Honda", "H3", "2016");

    cout<<"Brand is:"<<obj.Brand<<endl;
    cout<<"Model is:"<<obj.Model<<endl;
    cout<<"Year is:"<<obj.Year<<endl;

    cout<<"Brand is:"<<obj1.Brand<<endl;
    cout<<"Model is:"<<obj1.Model<<endl;
    cout<<"Year is:"<<obj1.Year<<endl;

    return 0;
}

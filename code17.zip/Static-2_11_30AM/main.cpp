#include <iostream>

using namespace std;

//Static variable inside function

class counter
{
public:

    void updateCount()
    {
        static int count; //same as static int count  0;
        cout<<count++<<" ";
    }
};

int main()
{
    counter obj;
    for(int i=0; i<5; i++)
        obj.updateCount();

    return 0;
}

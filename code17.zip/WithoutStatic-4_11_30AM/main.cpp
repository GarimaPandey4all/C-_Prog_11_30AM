#include <iostream>

using namespace std;

//Same as previous example but without using static keyword

void updateCount()
{
    int count = 0; //initialize with zero to count variable is must here
    cout<<count++<<" ";
}

int main()
{
    for(int i=0; i<5; i++)
        updateCount();

    return 0;
}

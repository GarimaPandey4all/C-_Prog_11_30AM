#include <iostream>

using namespace std;

//Static variable inside function but without class

void updateCount()
{
    static int count;
    cout<<count++<<" ";
}


int main()
{
    for(int i=0; i<5; i++)
        updateCount();

    return 0;
}

#include <iostream>

using namespace std;

//void swap(int, int); //function declaration

void swap(int &x, int &y) //function definition
{
    int temp = x;
    x = y;
    y = temp;
}

int main()
{
    int a = 45, b = 35;

    cout<<"Before Swapping:\n";
    cout<<"a = "<<a<<" b = "<<b<<endl;

    swap(a, b); //function calling

    cout<<"After swapping with pass by reference:\n";
    cout<<"a = "<<a<<" b = "<<b<<endl;

    return 0;
}

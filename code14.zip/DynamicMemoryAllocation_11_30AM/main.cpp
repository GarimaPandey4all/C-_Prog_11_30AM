#include <iostream>

using namespace std;

int main()
{
    //C syntax of Dynamic Memory Allocation

//    int *pvalue = NULL;
//
//    pvalue = (int *)malloc(10 * sizeof(int));
//
//    *pvalue = 20;
//
//    cout<<"Pvalue is:"<<*pvalue;
//
//    free(pvalue);
//    pvalue = NULL;

    //C++ syntax of Dynamic Memory Allocation

    int *pvalue  = NULL;

    pvalue = new int;

    *pvalue = 20;

    cout<<"Pvalue is:"<<*pvalue;

    delete pvalue;

    pvalue = NULL;

    return 0;
}

#include <iostream>

using namespace std;

class Parent
{
protected:
    int id_Protected;
};

class Child : public Parent
{
public:
    //setter
    void setId(int id)
    {
        id_Protected = id;
    }

    //getter
    void displayId()
    {
        cout<<"Id is:"<<id_Protected;
    }
};


int main()
{
    Child obj;

    obj.setId(101);
    obj.displayId();

    return 0;
}

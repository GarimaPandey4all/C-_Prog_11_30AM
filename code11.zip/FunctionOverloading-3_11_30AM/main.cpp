#include <iostream>

using namespace std;

class Calculator
{
public:

    void add(int a, int b)
    {
        cout<<"Addition is:"<<a+b<<endl;
    }

    void add(float a, float b)
    {
        cout<<"Addition is:"<<a+b<<endl;
    }

    void add(double a, double b)
    {
        cout<<"Addition is:"<<a+b<<endl;
    }

    void sub(float a, float b)
    {
        cout<<"Subtraction is:"<<a-b<<endl;
    }

    void sub(int a, int b)
    {
        cout<<"Subtraction is:"<<a-b<<endl;
    }

    void mul(int a, int b)
    {
        cout<<"Multiplication is:"<<a*b<<endl;
    }

    void mul(float a, float b)
    {
        cout<<"Multiplication is:"<<a*b<<endl;
    }

    void div(int a, int b)
    {
        cout<<"Division is:"<<a/b<<endl;
    }

    void div(double a, double b)
    {
        cout<<"Division is:"<<a/b<<endl;
    }
};

int main()
{
    Calculator obj;

    obj.add(10, 20);
    obj.add(23.5f, 56.7f);
    obj.add(23.6, 45.8);

    obj.sub(34, 6);
    obj.sub(34.7f, 10.7f);

    obj.mul(2, 4);
    obj.mul(3.6f, 2.6f);

    obj.div(10, 2);
    obj.div(23.5, 10.5);

    return 0;
}

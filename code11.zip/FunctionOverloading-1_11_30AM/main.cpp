#include <iostream>

using namespace std;

/*
    Polymorphism- OOPs

    Poly - many
    morphism - forms

    Two Types:

    1. Compile Time Polymorphism
    -Method/function Overriding
    -Function Overloading
    -Operator Overloading

    2. Runtime Polymorphism
    -Virtual Functions
*/

/*
    Function Overloading: Function name same for all functions.
                          Type of parameters different in all the functions
                          Number of parameters different in all the functions

*/

class funcOverloading
{
public:
    void func(int a)
    {
        cout<<"A is:"<<a<<endl;
    }

    void func(int x, int y)
    {
        cout<<"X is:"<<x<<"Y is:"<<y<<endl;
    }

    void func(float z)
    {
        cout<<"Z is:"<<z;
    }
};

int main()
{
    funcOverloading obj;

    obj.func(10);
    obj.func(10, 20);
    obj.func(23.6f);

    return 0;
}

#include <iostream>

using namespace std;

class Addition
{
public:
    void add(int a, int b)
    {
        cout<<"Addition is:"<<a+b<<endl;
    }

    void add(float a, float b)
    {
        cout<<"Addition is:"<<a+b<<endl;
    }

    void add(double a, double b)
    {
        cout<<"Addition is:"<<a+b<<endl;
    }
};

int main()
{
    Addition obj;

    obj.add(10, 20);
    obj.add(10.4f, 23.7f);
    obj.add(40.9, 56.9);

    return 0;
}

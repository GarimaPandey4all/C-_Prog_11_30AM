#include <iostream>

using namespace std;

class A
{
public:
    virtual void display()
    {
        cout<<"Base Class";
    }
};

class B : public A
{
public:
    void display()
    {
        cout<<"Derived Class";
    }
};

int main()
{
    A *a; //pointer base class

    B b; // object of derived class

    a = &b;

    a->display();

    return 0;
}

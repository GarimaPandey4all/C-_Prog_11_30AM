#include <iostream>

using namespace std;

class demo
{
    int x;
public:

    demo(int i)
    {
        x = i;
    }

    void operator+(demo); //declare
};

void demo :: operator+ (demo d)
{
    int y;

    y = x + d.x;

    cout<<"Addition of two objects is:"<<y<<endl;
}

int main()
{

    demo obj(3);

    demo obj2(2);

    obj + obj2; //obj.add(obj2);

    return 0;
}

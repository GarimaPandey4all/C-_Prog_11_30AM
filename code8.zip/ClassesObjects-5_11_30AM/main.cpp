#include <iostream>

using namespace std;

class Myclass
{
public:
    Myclass(); //Constructor Declare
};

Myclass::Myclass()
{
    cout<<"I am constructor."<<endl;
}

int main()
{
    Myclass obj;
    Myclass obj1;
    Myclass obj2;

    return 0;
}

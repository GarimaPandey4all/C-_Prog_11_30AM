#include <iostream>

using namespace std;

/*
    Access Specifiers:

    1. Public
    2. Private: Default
    3. Protected

*/

class varAssign
{
public:
    int x;

//private:
    int y;
};

int main()
{
    varAssign obj;
    obj.x = 10;

    obj.y = 20;

    cout<<"X is:"<<obj.x<<endl;
    cout<<"Y is:"<<obj.y<<endl;

    return 0;
}

#include <iostream>

using namespace std;

/*

    1. Function definition inside the class
    2. Function definition outside the class

*/

class Human
{
public:
    void showdata(); //Function Declaration
};

void Human::showdata() // ::--> Scope Resolution Operator
{
    cout<<"I am Human.";
}

int main()
{
    Human obj;
    obj.showdata();

    return 0;
}

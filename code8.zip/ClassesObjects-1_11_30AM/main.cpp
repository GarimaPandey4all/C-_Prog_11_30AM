#include <iostream>

using namespace std;

class HelloWorld
{
public: //Access Specifier

    void ShowData() //Function definition
    {
        cout<<"Hello World."<<endl;
    }
};

int main()
{
    HelloWorld obj;
    HelloWorld obj1;

    obj.ShowData(); //Calling
    obj1.ShowData();

    return 0;
}

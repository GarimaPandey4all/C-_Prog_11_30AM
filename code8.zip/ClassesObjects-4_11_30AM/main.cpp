#include <iostream>

using namespace std;

class Myclass
{
public:

    Myclass() //Constructor: name of constructor and name of class both are same.
    {
        cout<<"I am constructor"<<endl;
    }
};


int main()
{
    Myclass obj;
    Myclass obj1;
    return 0;
}

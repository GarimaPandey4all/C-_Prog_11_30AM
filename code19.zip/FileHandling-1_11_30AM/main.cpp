#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    //writing in  a file

    ofstream outfile("Test.txt", ios::out);

    //outfile.open("Test.txt", ios::out);

    outfile<<"Garima"<<endl;
    outfile<<"Swati"<<endl;
    outfile<<"Welcome to Brain Mentors";

    outfile.close();

    return 0;
}

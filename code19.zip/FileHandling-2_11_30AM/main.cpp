#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    //writing in a file

    ofstream outfile("Test.txt", ios::app);

    outfile<<endl<<"Garima"<<endl;
    outfile<<"Swati"<<endl;
    outfile<<"Welcome to Brain Mentors"<<endl;

    outfile<<"C++"<<endl;
    outfile<<"File Handling"<<endl;
    outfile<<"Welcome to Brain Mentors"<<endl;

    outfile.close();

    return 0;
}

#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> v1;

    cout<<"Current Capacity is:"<<v1.capacity()<<endl;

    for(int i=0; i<10; i++)
        v1.push_back(10*(i+1));

    cout<<"Values in vector:\n";
//    for(int i=0; i<10; i++)
//        cout<<v1[i]<<endl;

    for(int i=0; i<v1.size(); i++)
        cout<<v1[i]<<endl;

    cout<<"Size of vector is:"<<v1.size()<<endl; // 10
    cout<<"Current Capacity is:"<<v1.capacity()<<endl; // 16

    v1.pop_back();

    cout<<"\nAfter pop the value from an vector:\n";
    for(int i=0; i<v1.size(); i++)
        cout<<v1[i]<<endl;

    cout<<"Size of vector is:"<<v1.size()<<endl; // 10
    cout<<"Current Capacity is:"<<v1.capacity()<<endl; // 16

    return 0;
}

#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <string> l1 {"New Delhi", "Mumbai", "Chandigarh"};

    //cout<<l1[0]; error

    l1.push_back("Kerala");

    l1.push_front("Jammu");

    //Iterator used to access the values from the list

    list <string> :: iterator ptr = l1.begin();

    while(ptr != l1.end())
    {
        cout<<*ptr<<" ";
        ++ptr;
    }

    cout<<"\nTotal number of elements in list are:"<<l1.size();

    return 0;
}

#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1 {50, 90, 10, 30, 60};

    list <int> :: iterator ptr = l1.begin();

    while(ptr != l1.end())
    {
        cout<<*ptr<<" ";
        ++ptr;
    }

    cout<<"\nTotal number of elements in list are:"<<l1.size();

    cout<<endl<<endl;

    l1.remove(10);

    list <int> :: iterator ptr2 = l1.begin();

    while(ptr2 != l1.end())
    {
        cout<<*ptr2<<" ";
        ++ptr2;
    }

    cout<<"\nTotal number of elements in list are:"<<l1.size();

    return 0;
}

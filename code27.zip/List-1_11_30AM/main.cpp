#include <iostream>
#include <list>

using namespace std;

/*
        List:

        1. List class supports a bidirectional linear list.
        2. Vector supports random access but a list can be accessed sequentially only.
        3. List can be accessed front to back or back to front.

*/

int main()
{
    list <int> l1;

    list <string> l2 {"India", "Kathmandu"};

    list <int> l3 {10, 20, 30, 40, 50, 60, 70, 80};

    return 0;
}

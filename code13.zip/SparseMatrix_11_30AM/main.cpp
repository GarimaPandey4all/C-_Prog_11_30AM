#include <iostream>

using namespace std;

int main()
{
   int matrix[5][5], i, j, rows, columns, total = 0;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns:";
    cin>>columns;

    cout<<"Enter "<<rows*columns<<" values in matrix:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"\nMatrix:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    //Logic for Sparse Matrix
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j] == 0)
            {
                total++;
            }
        }
    }

    if(total > (rows*columns)/2)
        cout<<"\nSparse Matrix.";
    else
        cout<<"\nNot a Sparse Matrix.";

    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    int matrix[5][5], i, j, rows, columns, temp[5][5], count = 1;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns:";
    cin>>columns;

    cout<<"Enter "<<rows*columns<<" values in matrix:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"\nMatrix:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    //Transpose of a Matrix
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            temp[j][i] = matrix[i][j];
        }
    }

    cout<<"\nTranspose Matrix:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<temp[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j] != temp[i][j])
            {
                count++;
                break;
            }
        }
    }

    if(count == 1)
        cout<<"Symmetric Matrix.";
    else
        cout<<"Not a Symmetric Matrix.";

    return 0;
}

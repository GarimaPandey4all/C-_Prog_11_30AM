#include <iostream>

using namespace std;

int main()
{
    int matrix1[5][5], matrix2[5][5], i, j, temp[5][5], rows, columns;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns:";
    cin>>columns;

    cout<<"Enter "<<rows*columns<<" values in matrix-1:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Enter "<<rows*columns<<" values in matrix-2:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix2[i][j];
        }
    }

    cout<<"\nMatrix-1:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }

    cout<<"\nMatrix-2:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix2[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            temp[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }

    cout<<"\nAddition of two matrices:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<temp[i][j]<<"\t";
        }
        cout<<endl;
    }

    return 0;
}

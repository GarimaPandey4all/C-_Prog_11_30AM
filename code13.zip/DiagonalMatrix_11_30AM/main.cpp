#include <iostream>

using namespace std;

int main()
{
    int matrix[5][5], i, j, rows, columns;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns:";
    cin>>columns;

    cout<<"Enter "<<rows*columns<<" values in matrix:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"\nMatrix:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    //Diagonal Matrix
    cout<<"\nDiagonal Matrix values are:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(i == j)
            {
                cout<<matrix[i][j]<<"  ";
            }
        }
    }

    return 0;
}

#include <iostream>

using namespace std;

class base
{
public:
    virtual void print()
    {
        cout<<"Print base class"<<endl;
    }

    virtual void show()
    {
        cout<<"Show base class"<<endl;
    }

    void basedisplay()
    {
        cout<<"Base Display";
    }
};

class derived : public base
{
public:
    void print()
    {
        cout<<"Print derived class"<<endl;
    }

    void show()
    {
        cout<<"Show derived class"<<endl;
    }

    void display()
    {
        cout<<"This is display derived class";
    }
};

int main()
{
    base* bptr;
    derived d;
    bptr = &d;

    //Virtual Function, binded at runtime
    bptr->print();

    //Non-Virtual Function, binded at compile time
    bptr->show();

    d.display();

    return 0;
}

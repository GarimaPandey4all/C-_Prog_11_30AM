#include <iostream>

using namespace std;

/*
        4 + i7-->C1
        2 + i9-->C2
        6 + i16
*/

class Complex
{
private:
    int real;
    int imag;

public:
    Complex(int r = 0, int i = 0)
    {
        real = r;
        imag = i;
    }
};

int main()
{
    Complex C1(4, 7);
    Complex C2(2, 9);
    Complex C3;

    C3 = C1 + C2; //error

    return 0;
}

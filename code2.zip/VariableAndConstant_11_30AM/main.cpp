#include <iostream>
#define MONTHS 12 //Macros

using namespace std;

int main()
{
//    const float pi = 3.14f;
//
//    const int MONTHS = 12;

    const int a = 10;

    cout<<"Value of a:"<<a<<endl;

//    a = 30;
//
//    a = 60;

//    cout<<"Value of a:"<<a;

    return 0;
}

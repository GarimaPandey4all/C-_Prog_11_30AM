#include <iostream>

using namespace std;

/* a+b -->Expression
    a, b-->operands
    +-->Operator

*/


int main()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    //Arithmetic Operators

    cout<<"Addition is:"<<a+b<<endl;

    cout<<"Subtraction is:"<<a-b<<endl;

    cout<<"Multiplication is:"<<a*b<<endl;

    cout<<"Division is:"<<a/b<<endl; //output is quotient

    cout<<"Modulus Operator is:"<<a%b<<endl; //output is remainder //a = 10, b = 5 // 0

    //Pre and Post Increment

    cout<<"Pre-Increment is:"<<++a<<endl; //a = 10, output a = 11

    cout<<"Post-Increment is:"<<b++<<endl; //b = 5, output b = 5

    //Pre and Post Decrement

    cout<<"Pre-Decrement is:"<<--a<<endl; //a = 11, output a = 10

    cout<<"Post-Decrement is:"<<b--<<endl; //b = 6, output b = 6

    cout<<"b is:"<<b;

    return 0;
}

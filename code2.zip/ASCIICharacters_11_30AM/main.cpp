#include <iostream>

using namespace std;

int main()
{
    char ch;

    cout<<"Enter any value";
    cin>>ch;

    cout<<"Value is:"<<ch;

    return 0;
}

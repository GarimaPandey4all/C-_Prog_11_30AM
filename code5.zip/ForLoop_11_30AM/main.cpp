#include <iostream>
#define MONTHS 12

using namespace std;

int main()
{
    int days[MONTHS] = {31, 29, 30, 31, 30, 31, 30, 31, 30, 30, 31, 31};
    int i;

    for(i=0; i<MONTHS; i++)
        cout<<i+1<<" month has "<<days[i]<<" days."<<endl;

    return 0;
}

#include <iostream>
#include <fstream>

using namespace std;

//Read particular line of content from the existing file.

int main(int argc, char *argv[])
{
    int position;

    ifstream infile;

    infile.open("Test.txt", ios::in);

    infile.seekg(22, ios::beg);

    position = infile.tellg();

    cout<<"Current position of get pointer is:"<<position<<endl;

    //Read  the next 14 characters from the file into a buffer
    char A[22];
    infile.read(A, 14);

    A[14] = 0; //End the buffer with null character

    cout<<"Content from a file is:"<<A<<endl;

    infile.close();

    return 0;
}

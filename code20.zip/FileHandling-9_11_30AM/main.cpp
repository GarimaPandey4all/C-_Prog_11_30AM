#include <iostream>
#include <fstream>

using namespace std;

//Content add at particular position

int main()
{
    int position;

    ofstream outfile("Test.txt", ios::out);

    //Write content in a file
    outfile<<"This is an apple.";

    position = outfile.tellp();

    cout<<"Current position of pointer is:"<<position;

    //move/set pointer position
    outfile.seekp(position - 8);
    outfile<<" sam";
    outfile.close();

    return 0;
}

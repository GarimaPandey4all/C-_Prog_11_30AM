#include <iostream>
#include <fstream>

using namespace std;

//Content add at particular position

int main()
{
    int position;

    ofstream outfile("Test.txt", ios::out);

    //Write content in a file
    outfile.write("This is an apple.", 17);

    position = outfile.tellp();

    //move/set pointer position
    outfile.seekp(position - 8);
    outfile.write(" sam", 4);
    outfile.close();

    return 0;
}

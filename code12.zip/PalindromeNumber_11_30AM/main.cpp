#include <iostream>

using namespace std;

/*
    121 = 121

    123 = 321 = not

    1001 = 1001

*/


int main()
{
    int n, r, sum = 0, temp;

    cout<<"Enter any number to check whether the number is palindrome or not:";
    cin>>n;

    temp = n;

    while(n > 0)
    {
        r = n % 10; //n = 121 // 1, 2, 1
        sum = sum * 10 + r; // sum=1, 12, 121
        n = n / 10; //12, 1, 0
    }

    n = temp;

    (n == sum) ? cout<<"Number is Palindrome.":cout<<"Number is not Palindrome.";

    return 0;
}

#include <iostream>

using namespace std;

/*
    Sum of digits:

    121 = 1 + 2 + 1 = 4

    521 = 5 + 2 + 1 = 8

*/


int main()
{
    int n, r, sum = 0;

    cout<<"Enter any number:";
    cin>>n;

    while(n > 0)
    {
        r = n % 10; //n = 121 // 1, 2, 1
        sum = sum + r; // sum=1, 12, 121
        n = n / 10; //12, 1, 0
    }

    cout<<"Sum of digits is:"<<sum;

    return 0;
}

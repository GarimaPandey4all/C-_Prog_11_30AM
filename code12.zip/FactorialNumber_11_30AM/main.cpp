#include <iostream>

using namespace std;

/*
    factorial Number:

    5! = 5 * 4 * 3 * 2 * 1 = 120

*/

int main()
{
    int n, i, fact = 1;

    cout<<"Enter any number to check their factorial value:";
    cin>>n;

    for(i=1; i<=n; i++)
        fact *= i; //fact = fact * i; Assignment Operator

    cout<<"Factorial of "<<n<<"! is:"<<fact;

    return 0;
}

#include <iostream>

using namespace std;

/*
    Reverse Number

    121 = 121

    123 = 321

    1001 = 1001

*/


int main()
{
    int n, r, reverse = 0;

    cout<<"Enter any number:";
    cin>>n;

    while(n > 0)
    {
        r = n % 10; //n = 121 // 1, 2, 1
        reverse = reverse * 10 + r; // sum=1, 12, 121
        n = n / 10; //12, 1, 0
    }

    cout<<"Reverse number is:"<<reverse;

    return 0;
}

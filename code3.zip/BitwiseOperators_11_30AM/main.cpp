#include <iostream>

using namespace std;

int main()
{
    int A = 5, B = 6;

    cout<<"Bitsise And Operator:"<<(A & B)<<endl;

    cout<<"Bitsise OR Operator:"<<(A | B)<<endl;

    cout<<"Bitsise X-OR Operator:"<<(A ^ B)<<endl;

    cout<<"Bitsise Left Shift Operator:"<<(A<<2)<<endl;

    cout<<"Bitsise Right Shift Operator:"<<(A>>2)<<endl;

    cout<<"Bitwise Not operator:"<<(~A)<<endl;

    return 0;
}

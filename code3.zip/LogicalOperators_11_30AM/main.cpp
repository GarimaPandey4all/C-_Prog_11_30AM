#include <iostream>

using namespace std;

int main()
{
    int A, B;

    cout<<"Enter any number for A and B:";
    cin>>A>>B;

    //Logical Operaators

    if(A && B)
        cout<<"This is (A && B)."<<endl;
    if(A || B)
        cout<<"This is (A || B)."<<endl;
    if(!(A && B))
        cout<<"This is !(A && B)."<<endl;

    return 0;
}

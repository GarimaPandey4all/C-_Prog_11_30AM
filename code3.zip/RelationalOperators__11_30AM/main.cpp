#include <iostream>

using namespace std;

int main()
{
    int A, B;

    cout<<"Enter any number for A and B:";
    cin>>A>>B;

    //Relational Operators

    if(A == B)
        cout<<"A is equal to B."<<endl;
    if(A != B)
        cout<<"A is not equal to B."<<endl;
    if(A >= B)
        cout<<"A is greater and equal to B."<<endl;
    if(A <= B)
        cout<<"A is less and equal to B."<<endl;

    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A, B;

    printf("Enter ")
    return 0;
}

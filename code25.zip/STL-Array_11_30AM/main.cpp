#include <iostream>
#include <array>

using namespace std;

int main()
{
    //array <int, 5> dataarray; //declaration

    array <int, 5> dataarray = {10, 20, 30, 40, 50}; //declaration and initialization
    array <int, 5> dataarray2 = {1, 2, 3, 4, 5};
    //at()

    cout<<"Value is:"<<dataarray.at(1)<<endl<<endl;

    //[]operator

    cout<<"Value is:"<<dataarray[4]<<endl<<endl;

    //front() and back()

    cout<<"First element is:"<<dataarray.front()<<endl;

    cout<<"Last element is:"<<dataarray.back()<<endl<<endl;

    //fill()

//    dataarray.fill(60);
//
//    cout<<"After fill() the values in an array are:"<<endl;
//    for(int i=0; i<5; i++)
//        cout<<dataarray[i]<<endl;

    //cout<<endl<<endl;

    //swap()

    dataarray.swap(dataarray2);

    cout<<"Array - 1:\n";
    for(int i=0; i<dataarray.size(); i++)
        cout<<dataarray[i]<<endl;

    cout<<"Array - 2:\n";
    for(int i=0; i<dataarray2.size(); i++)
        cout<<dataarray2[i]<<endl;

    cout<<endl;
    //size()

    cout<<"Size of Array-1:"<<dataarray.size()<<endl;

    //empty()

    //dataarray.fill(0);

    cout<<"Empty the Array-1:"<<dataarray.empty()<<endl;

    //max_size()

    cout<<"Max size of the array:"<<dataarray.max_size();

    return 0;
}

#include <iostream>

using namespace std;

/*
    Function Template:

    template <class T>
    T function_name(T a, T b)
    {
        //block of statements
    }

*/

template <class T>
T Add(T a, T b)
{
    cout<<endl<<a+b;
}

int main()
{
    cout<<endl<<"Addition of Integer Value:";
    Add(10, 20);
    cout<<endl;

    cout<<endl<<"Addition of Float Value:";
    Add(20.50f, 50.78f);
    cout<<endl;

    cout<<endl<<"Addition of Double Value:";
    Add(12.45, 45.69);
    cout<<endl;

    return 0;
}

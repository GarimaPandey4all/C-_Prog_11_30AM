#include <iostream>

using namespace std;

int main()
{
    int a = 5, b = 6;

//    cout<<"Before swapping the vale of a="<<a<<" and b="<<b<<endl;
//
//    //First Way: + and -
//
//    a = a + b; //11
//    b = a - b; //5
//    a = a - b; //6
//
//    cout<<"After swapping the vale of a="<<a<<" and b="<<b;


    //Second Way: * and /

    cout<<"Before swapping the vale of a="<<a<<" and b="<<b<<endl;

    a = a * b; //30
    b = a / b; //5
    a = a / b; //6

    cout<<"After swapping the vale of a="<<a<<" and b="<<b<<endl;

    //cout<<"Address of a:"<<&a; //& --> address of operator

    return 0;
}

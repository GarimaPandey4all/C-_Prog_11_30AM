#include <iostream>

using namespace std;

int main()
{
    int a = 5, b = 6;

    /*
        a = 5 = 0101

        b = 6 = 0110

                0011= 3
                0101= 5
                0110= 6
    */

    cout<<"Before swapping the vale of a="<<a<<" and b="<<b<<endl;

    //Logic X-OR

    a = a ^ b; //3
    b = a ^ b; //5
    a = a ^ b; //6

    cout<<"After swapping the vale of a="<<a<<" and b="<<b;

    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    int array[5], i, sum = 0;

    cout<<"Enter values in an array[i]:\n";
    for(i=0; i<5; i++)
    {
       cin>>array[i];
    }

    for(i=0; i<5; i++)
    {
        sum += array[i];
    }

    cout<<"Addition is:"<<sum;

    return 0;
}

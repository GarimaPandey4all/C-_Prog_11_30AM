#include <iostream>

using namespace std;

int main()
{
    int a, b, c, largest;

    cout<<"Enter any value for a, b and c:";
    cin>>a>>b>>c;

    largest = (a>b) ? ((a>c) ? a : c) : ((b>c) ? b : c);

    cout<<"Largest number between three numbers is:"<<largest;

//    if((a>b) && (a>c))
//        cout<<"Largest number is:"<<a;
//    else if(b>c)
//        cout<<"Largest number is:"<<b;
//    else
//        cout<<"Largest number is:"<<c;

    return 0;
}

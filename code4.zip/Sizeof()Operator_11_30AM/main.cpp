#include <iostream>

using namespace std;

int main()
{
    //int a;

    cout<<"Size of int:"<<sizeof(int)<<endl;
    cout<<"Size of float:"<<sizeof(float)<<endl;
    cout<<"Size of char:"<<sizeof(char)<<endl;
    cout<<"Size of double:"<<sizeof(double)<<endl;

    return 0;
}

#include <iostream>

using namespace std;

/*
        Switch :

        Menu Driven Program.
*/


int main()
{
    int a, b;
    int choice;

    while(1) //for(;;)
    {
        cout<<"\n\n1. Addition.";
        cout<<"\n2. Subtraction.";
        cout<<"\n3. Multiplication";
        cout<<"\n4. Division.";
        cout<<"\n5. Exit.";
        cout<<"\n\nEnter your choice:";
        cin>>choice;

        switch(choice)
        {
        case 1:
            cout<<"Enter any value for a and b:";
            cin>>a>>b;

            cout<<"Addition is:"<<a+b;
            break;

        case 2:
            cout<<"Enter any value for a and b:";
            cin>>a>>b;

            cout<<"Subtraction is:"<<a-b;
            break;

        case 3:
            cout<<"Enter any value for a and b:";
            cin>>a>>b;

            cout<<"Multiplication is:"<<a*b;
            break;

        case 4:
            cout<<"Enter any value for a and b:";
            cin>>a>>b;

            cout<<"Division is:"<<a/b;
            break;

        case 5:
            exit(0);

        default:
            cout<<"Invalid choice.";
        }
    }

    return 0;
}

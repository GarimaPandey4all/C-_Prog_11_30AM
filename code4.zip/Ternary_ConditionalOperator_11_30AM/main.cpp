#include <iostream>

using namespace std;

/*

        Unary - 1
        Binary - 2
        Ternary -3

        Conditional/Ternary Operator : (?:)

        expression1 ? expression2 : expression3

        (condition) ? True : False

*/



int main()
{
    int number;

    cout<<"Enter any number:";
    cin>>number;

//    if((number%2) == 0)
//        cout<<"Number is Even.";
//    else
//        cout<<"Number is Odd.";

    ((number%2)==0)? cout<<"Number is Even." : cout<<"Number is Odd.";

    return 0;
}

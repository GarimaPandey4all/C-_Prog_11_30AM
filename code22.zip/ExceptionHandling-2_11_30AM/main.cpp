#include <iostream>

using namespace std;

void Myfunc()
{
    throw 10;
}

int main()
{
    try
    {
        Myfunc(); //function calling

        cout<<"Try Block."<<endl;
    }

    catch(...)
    {
        cout<<"Exception here.";
    }

//    catch(int e)
//    {
//        cout<<"Exception is:"<<e<<endl;
//    }

    return 0;
}

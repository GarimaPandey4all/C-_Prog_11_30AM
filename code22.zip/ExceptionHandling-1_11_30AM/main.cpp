#include <iostream>

using namespace std;

int main()
{
    cout<<"Exception Handling."<<endl;

    double value = 10.1;

    try
    {
        if(value == 10)
            throw 10;
        if(value == 10.8)
            throw 10.8;
        if(value == 'A')
            throw 'A';

        cout<<"Try Block."<<endl;
    }

    catch(int e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(double e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(char e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    cout<<"Outside the try and catch block.";

    return 0;
}

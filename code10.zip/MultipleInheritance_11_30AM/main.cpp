#include <iostream>

using namespace std;

class parent1
{
public:
    int parent1;
};

class parent2
{
public:
    int parent2;
};

class child : public parent1 , public parent2
{
public:
    int child;
};

int main()
{

    child obj;

    obj.child = 20;
    obj.parent1 = 40;
    obj.parent2 = 60;

    cout<<"Child is:"<<obj.child<<endl;
    cout<<"Parent-1 is:"<<obj.parent1<<endl;
    cout<<"Parent-2 is:"<<obj.parent2<<endl;

    return 0;
}

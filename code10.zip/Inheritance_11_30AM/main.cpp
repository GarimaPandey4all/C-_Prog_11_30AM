#include <iostream>

using namespace std;

/*
    Inheritance has five types:

    1. Single Inheritance
    2. Multiple Inheritance
    3. Multilevel Inheritance
    4. Heirarchical Inheritance
    5. Hybrid Inheritance

    Parent = Base
    Child = Derived

*/

//Single Inheritance

class parent //base class
{
public:
    int id_parent;
};

//Derived Class
class child : public parent
{
public:
    int id_child;
};

int main()
{
    child obj;
    obj.id_child = 10;
    obj.id_parent = 20;

    cout<<"Child Id is:"<<obj.id_child<<endl;
    cout<<"Parent Id is:"<<obj.id_parent<<endl;

    return 0;
}

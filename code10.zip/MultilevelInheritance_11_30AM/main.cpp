#include <iostream>

using namespace std;

class parent
{
public:
    int parent;
};

class child1 : public parent
{
public:
    int child1;
};

class child2 : public child1
{
public:
    int child2;
};

int main()
{
    child2 obj;

    obj.child2 = 2;
    obj.child1 = 4;
    obj.parent = 6;

    cout<<"Parent is:"<<obj.parent<<endl;
    cout<<"Child1 is:"<<obj.child1<<endl;
    cout<<"Child2 is:"<<obj.child2<<endl;

    return 0;
}

#include <iostream>

using namespace std;

class Vehicle
{
public:
    Vehicle()
    {
        cout<<"This is Vehicle Class."<<endl;
    }
};

class car : public Vehicle
{
public:

    car()
    {
        cout<<"This is car class."<<endl;
    }
};

class bus : public Vehicle
{
public:
    bus()
    {
        cout<<"This is bus class."<<endl;
    }
};

int main()
{
    car c;
    bus b;

    return 0;
}

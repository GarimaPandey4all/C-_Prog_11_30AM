#include <iostream>

using namespace std;

/*
    Hybrid = Multiple + Heirarchical

*/

class Vehicle
{
public:
    Vehicle()
    {
        cout<<"This is Vehicle Class."<<endl;
    }
};

class FourWheeler
{
public:
    FourWheeler()
    {
        cout<<"This is FourWheeler class."<<endl;
    }
};

//Multiple Inheritance
class car : public Vehicle , public FourWheeler
{
public:
    car()
    {
        cout<<"This is car class."<<endl;
    }
};

//Heirarchical Inheritance
class bus : public Vehicle
{
public:
    bus()
    {
        cout<<"This is bus class."<<endl;
    }
};

int main()
{
    car c;
    bus b;

    return 0;
}

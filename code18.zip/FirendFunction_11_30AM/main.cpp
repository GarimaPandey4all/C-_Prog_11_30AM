#include <iostream>

using namespace std;

class sum
{
private:
    int a, b;

public:
    void setData(int x, int y)
    {
        a = x;
        b = y;
    }

    void getData()
    {
        cout<<"a="<<a<<" b="<<b<<endl;
    }

    friend void func(sum); // friend function declaration
};

void func(sum s) //friend function definition outside the class
{
    cout<<"Sum is:"<<s.a+s.b;
}

int main()
{
    sum obj; //creating a object of a class
    obj.setData(10, 20); //calling normal member function
    obj.getData();

    func(obj); //calling friend function by using class's object

    return 0;
}

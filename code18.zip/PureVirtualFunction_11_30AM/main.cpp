#include <iostream>

using namespace std;

//An abstract class
class Demo
{
public:
    //Pure virtual function or abstract function

    virtual void func() = 0;

};

class child : public Demo
{
public:
    void func() //overriding function
    {
        cout<<"func() block.";
    }
};

int main()
{
    child obj;

    obj.func();

    return 0;
}

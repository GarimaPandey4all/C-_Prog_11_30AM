#include <iostream>

using namespace std;

class student
{
private:
    string name;
    int age;

public:

    void setStudent(string n, int a)
    {
        name = n;
        age = a;
    }

    void showStudent()
    {
        cout<<"Name of student is:"<<name<<endl;
        cout<<"Age of student is:"<<age<<endl;
    }
};

int main()
{
    student S1;

    S1.setStudent("Brain Mentors", 24);

    pair <string, int> p1;
    pair <string, string> p2;
    pair <string, float> p3;
    pair <int, student> p4;

    //Insert value in pair

    p1 = make_pair("Sarita", 11);
    p2 = make_pair("Sarita", "Sinha");
    p3 = make_pair("Swati", 3.5f);
    p4 = make_pair(25, S1);

    //Accessing the values from the pair

    cout<<"Pair 1:"<<p1.first<<" "<<p1.second<<endl;
    cout<<"Pair 2:"<<p2.first<<" "<<p2.second<<endl;
    cout<<"Pair 3:"<<p3.first<<" "<<p3.second<<endl;
    cout<<"Pair 4:"<<p4.first<<endl;

    student S2 = p4.second;

    S2.showStudent();

    //Relational Operators
    if(p1.first == p2.first)
        cout<<"P1 is equal to P2.";

    return 0;
}

#include <iostream>
#include <tuple>

using namespace std;

int main()
{
    tuple <string, int, int> t1;

    //Insert in tuple

    t1 = make_tuple("New Delhi", 10, 25);

    //Accessing the data from the tuple

    cout<<"Tuple 1:"<<get<0>(t1)<<" ";
    cout<<get<1>(t1)<<" ";
    cout<<get<2>(t1);

    return 0;
}

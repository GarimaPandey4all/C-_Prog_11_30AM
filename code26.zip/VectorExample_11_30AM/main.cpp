#include <iostream>
#include <vector>

using namespace std;

/*
    Vector supports dynamic array.
    Vector can provide memory flexibilty.
*/


int main()
{
    //vector <int> v1;

    vector <string> v1{"Brain", "Mentors", "C++"};

    cout<<"Current Capacity is:"<<v1.capacity();

    return 0;
}

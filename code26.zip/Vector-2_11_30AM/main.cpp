#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> v1;
    vector <char> v2(5);
    vector <int> v3(5, 10);
    vector <string> v4(4, "Hi");

    //subscript operator[]

    cout<<v4[0]<<endl;
    cout<<v4[1]<<endl;
    cout<<v4[2]<<endl;
    cout<<v4[3]<<endl;

    //at(), front() and back()

    cout<<"At():"<<v3.at(4)<<endl;
    cout<<"front():"<<v3.front()<<endl;
    cout<<"back():"<<v4.back()<<endl;

    return 0;
}

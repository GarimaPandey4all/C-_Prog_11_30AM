#include <iostream>

using namespace std;

class HelloWorld
{
public:

    void display() //member function
    {
        cout<<"Hello World.";
    }
};


int main()
{
    HelloWorld obj; //create class's object

    obj.display(); //by using object we called the function of the class

    int a;

    return 0;
}
